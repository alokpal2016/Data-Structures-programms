#include"queue.h"
int isempty(Node *rear)
{
  if(rear==NULL)
       return 1;
  else
       return 0;
}
