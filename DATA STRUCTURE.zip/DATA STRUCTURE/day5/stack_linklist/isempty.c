#include"stack.h"
int isempty(Node* top)
  {
    //Node *top;
    if(top==NULL)
          return 1;
    else
          return 0;
  }
