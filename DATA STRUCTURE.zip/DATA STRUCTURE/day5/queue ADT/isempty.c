#include"queue.h"
int isempty(Node *front)
{
  if(front==NULL)
       return 1;
  else
       return 0;
}
