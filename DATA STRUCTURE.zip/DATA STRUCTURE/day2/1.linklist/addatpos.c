#include"linklist.h"
#include<stdio.h>
Node *addatpos(Node *start,int data,int pos);
