void merge_sort(int [],int ,int );
void merge(int [],int [],int ,int ,int ,int);
void copy(int [],int [],int ,int );
