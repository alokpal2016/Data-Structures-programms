#include <stdio.h>

void quick(int arr[], int index, int num);
int create(int num);
int display(int arr[],int num);
int partition (int arr[], int index, int num);
void swap(int* a, int* b);
