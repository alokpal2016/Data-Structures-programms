#include "quick.h"

int display(int arr[],int num)
{
  for (int i = 0; i < num; i++)
  {
    printf("arr[%d]: %d\n",i,arr[i]);
  }
}
