#include "quick.h"

void main()
{
  int num;
  printf("Enter the size of array\n");
  scanf("%d",&num);
  create(num);

}
