#include"linklist.h"
#include<stdio.h>
Node *create_list(Node *last)
{
  int i,n,data;
  printf("enter the no of nodes:");
  scanf("%d",&n);
  last=NULL;
  if(n==0)
   return last;
  printf("enter the element to be inserted :");
  scanf("%d",&data);
  last=inserttoempty(last,data);
  for(i=1;i<n;i++)
  {
    printf("enter the element to be inserted:");
    scanf("%d",&data);
    last=insertatend(last,data);
  }
  return last;
}
