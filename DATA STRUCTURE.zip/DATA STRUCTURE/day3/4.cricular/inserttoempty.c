#include"linklist.h"
#include<stdio.h>
#include<stdlib.h>
Node *inserttoempty(Node *last,int data)
{
  Node *temp;
  temp=(Node*)malloc(sizeof(Node));
  temp->info=data;
  last=temp;
  last->next=last;
  return last;
}
