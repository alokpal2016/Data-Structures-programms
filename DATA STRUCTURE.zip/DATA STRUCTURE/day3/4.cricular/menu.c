#include<stdio.h>
#include<stdlib.h>
#include"linklist.h"
Node *menu(Node *last,int choice)
{
  int data,item,pos;
  switch (choice)
  {
    case 1: last=create_list(last);
            return last;
            break;
    case 2: display(last);
            return last;
            break;
    case 3: printf("enter the data to be inserted\n");
            scanf("%d",&data);
            last=insertatfront(last,data);
            return last;
            break;
    case 4: printf("enter the data to be inserted\n");
            scanf("%d",&data);
            last=insertatend(last,data);
            return last;
            break;
    case 5:
            exit(1);
    default:
            printf("wrong choice\n");
  }
}
