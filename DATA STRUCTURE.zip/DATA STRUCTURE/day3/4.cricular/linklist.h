typedef struct node
{
  int info;
  struct node *next;
}Node;

Node* menu(Node*,int);
Node *create_list(Node *);
void display(Node *);
Node *inserttoempty(Node *,int );
Node *insertatfront(Node *,int );
Node *insertatend(Node *,int );
