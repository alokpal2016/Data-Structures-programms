#include"linklist.h"
#include<stdio.h>
#include<stdlib.h>
Node *insertatend(Node *last,int data)
{
  Node *temp;
  temp=(Node*)malloc(sizeof(Node));
  temp->info=data;
  temp->next=last->next;
  last->next=temp;
  last=temp;
  return last;
}
