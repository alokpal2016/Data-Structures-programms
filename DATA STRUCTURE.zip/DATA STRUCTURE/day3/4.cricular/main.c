#include<stdio.h>
#include<stdlib.h>
#include"linklist.h"
Node *last=NULL;
int main()
  {
    int choice,data,item,pos;
    while (1)
  {
    printf("1.creat  criculr list\n");
    printf("2.display\n");
    printf("3.insert at front\n");
    printf("4.insert at end\n");
    printf("5.exit\n");
    printf("enter your choice\n");
    scanf("%d",&choice);
    last=menu(last,choice);
  }
}
