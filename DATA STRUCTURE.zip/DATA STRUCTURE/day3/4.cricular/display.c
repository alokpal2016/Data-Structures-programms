#include"linklist.h"
#include<stdio.h>
void display(Node *last)
{
  Node *p;
  if(last==NULL)
  {
    printf("the list is empty\n");
  }
  p=last->next;
  printf("the list is:\n");
  do
  {
    printf("%d\t",p->info);
    p=p->next;
  }while (p!=last->next);
  printf("\n");
}
