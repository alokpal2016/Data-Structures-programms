typedef struct node{
  float coef;
  int ex;
  struct node *next;
}Node;
Node *creat(Node *);
Node *insert_s(Node *,float,int);
Node *insert(Node *,float,int);
void display(Node *);
void poly_add(Node *,Node *);
