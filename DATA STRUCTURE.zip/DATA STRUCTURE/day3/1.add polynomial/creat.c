#include<stdio.h>
#include<stdlib.h>
#include"add.h"
Node *creat(Node *start)
{
  int i,n,ex;
  float coef;
  printf("enter the no of nodes:");
  scanf("%d",&n);
  for(i=0;i<n;i++)
  {
    printf("enter the coef:");
    scanf("%f",&coef);
    printf("enter the ex:");
    scanf("%d",&ex);
    start=insert_s(start,coef,ex);
  }
  return start;
}
