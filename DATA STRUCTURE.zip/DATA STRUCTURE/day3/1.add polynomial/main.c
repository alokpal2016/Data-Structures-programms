#include<stdio.h>
#include<stdlib.h>
#include"add.h"
int main()
{
  Node *start1=NULL, *start2=NULL;
  printf("enter the start1:\n");
  start1=creat(start1);
  printf("enter the start2:\n");
  start2=creat(start2);
  printf("print start 1:\n");
  display(start1);
  printf("print start 2:\n");
  display(start2);
  poly_add(start1,start2);
}
