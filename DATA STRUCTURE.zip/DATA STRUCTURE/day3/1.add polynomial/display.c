#include<stdio.h>
#include<stdlib.h>
#include"add.h"
void display(Node *ptr)
{
  if(ptr==NULL)
  {
    printf("polinomial is empty\n");
    return;
  }
  while(ptr!=NULL)
    {
      printf("(%.1fx^%d)",ptr->ex,ptr->coef);
      ptr=ptr->next;
      if(ptr!=NULL)
           printf("+");
      else
           printf("\n");
    }
}
