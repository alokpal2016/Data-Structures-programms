#include<stdio.h>
#include<stdlib.h>
#include"add.h"
Node *insert(Node *start,float coef,int ex)
{
  Node *ptr,*temp;
  temp=(Node *)malloc(sizeof(Node *));
  temp->coef=coef;
  temp->ex=ex;
  if(start==NULL)
  {
    temp->next=start;
    start=temp;
  }
  else
  {
    ptr=start;
    while(ptr->next!=NULL)
    ptr=ptr->next;
    temp->next=ptr->next;
    ptr->next=temp;
  }
  return start;
}
