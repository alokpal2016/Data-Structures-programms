#include<stdio.h>
#include<stdlib.h>
#include"add.h"
Node *insert_s(Node *start,float coef,int ex)
{
  Node *ptr,*temp;
  temp=(Node *)malloc(sizeof(Node *));
  temp->coef=coef;
  temp->ex=ex;
  if(start==NULL || ex>start->ex)
  {
    temp->next=start;
    start=temp;
  }
  else
  {
    ptr=start;
    while(ptr->next!=NULL && ptr->next->ex>=ex)
    ptr=ptr->next;
    temp->next=ptr->next;
    ptr->next=temp;
  }
  return start;
}
