#include<stdio.h>
#include<stdlib.h>
#include"add.h"
void poly_add(Node *p1,Node *p2)
{
  Node *start3;
  start3=NULL;
  while(p1!=NULL && p2!=NULL)
  {
    if(p1->ex > p2->ex)
    {
      start3 = insert(start3,p1->coef,p1->ex);
      p1=p1->next;
    }
    else if(p2->ex > p1->ex)
    {
      start3 = insert(start3,p2->coef,p2->ex);
      p2=p2->next;
    }
    else if(p1->ex == p2->ex)
    {
       start3 = insert(start3,p1->coef+p2->coef,p1->ex);
            p1=p1->next;
            p2=p2->next;
    }
  }
  while(p1!=NULL)
  {
      start3 = insert(start3,p1->coef,p1->ex);
      p1=p1->next;
  }
  while(p2!=NULL)
  {
      start3 = insert(start3,p2->coef,p2->ex);
      p2=p2->next;
  }
  printf("add polynomial is:");
  display(start3);
}
