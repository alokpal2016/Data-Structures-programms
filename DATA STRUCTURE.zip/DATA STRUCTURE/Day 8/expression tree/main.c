#include"exptree.h"
void main()
{
  struct node *root=NULL;
  printf("\n Enter thr postfix expression\n");
  char exp[100];
  scanf("%s",exp);
  struct stack mystack;
  mystack.top=-1;
  root=expressiontree(exp,&mystack);
  printf("\n");
  printf("The expression from post order traversal is\t");
  postorder(root);
  printf("\n");
  printf("The expression from inorder traversal is\t");
  inorder(root);
  printf("\n");
  printf("The expression from preorder traversal is\t");
  preorder(root);
  int height=treeheight(root)-1;
  printf("\nHeight of expression tree is %d\n",height);
  int count=nodecount(root);
  printf("Total number of nodes in the expression tree is %d\n",count);
  mirrortree(root);
  printf("\n");
  printf("The expression from postorder traversal of expression tree's mirror image is\t");
  postorder(root);
  printf("\n");
  printf("The expression from inorder traversal of expression tree's mirror image is\t");
  inorder(root);
  printf("\n");
  printf("The expression from preorder traversal of expression tree's mirror image is\t");
  preorder(root);
  printf("\n");
}
