#include"exptree.h"
void push(struct node *t,struct stack *mystack)
{
  if((mystack->top)==(SIZE-1))
  {
    printf("\n Stack Overflow");
    return;
  }
  (mystack->top)++;
  mystack->sta[mystack->top]=t;

}
