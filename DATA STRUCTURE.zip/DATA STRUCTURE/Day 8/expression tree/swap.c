#include"exptree.h"
void swap(struct node **p1,struct node **p2)
{
  struct node *temp;
  temp=*p1;
  *p2=*p1;
  *p1=temp;
}
