#include"exptree.h"
int treeheight(struct node *p)
{
  if(p==NULL)
  {
    return 0;
  }
  int rheight=treeheight(p->rchild);
  int lheight=treeheight(p->lchild);
  if(rheight>lheight)
    return rheight+1;
  else
    return lheight+1;
}
