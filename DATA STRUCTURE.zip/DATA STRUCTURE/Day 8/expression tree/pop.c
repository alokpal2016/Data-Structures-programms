#include"exptree.h"
struct node* pop(struct stack *mystack)
{
  if(mystack->top==-1)
  {
    printf("\nstack under flow\n");
    return NULL;
  }
  struct node* temp=mystack->sta[mystack->top];
  (mystack->top)--;
  return temp;
}
