#include"exptree.h"
void postorder(struct node *p)
{
  if(p==NULL)
    return;
  postorder(p->lchild);
  postorder(p->rchild);
  printf("%d ",p->data);
}
