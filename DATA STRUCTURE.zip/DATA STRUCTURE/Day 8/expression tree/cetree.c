#include"exptree.h"
struct node* expressiontree(char *str, struct stack *mystack)
{
  while(*str)
  {
    char temp;
    if((*str>='a')&&(*str<='z')||(*str>='A')&&(*str<='B')||(*str>='0')&&(*str<='9'))
    {
      struct node *temp= (struct node*) malloc(sizeof(struct node));
      temp->data=*str;
      temp->rchild=NULL;
      temp->lchild=NULL;
      push(temp,mystack);
    }
    else
    {
      struct node *temp= (struct node*) malloc(sizeof(struct node));
      temp->data=*str;
      temp->rchild=pop(mystack);
      temp->lchild=pop(mystack);
      push(temp,mystack);

    }
    str++;
  }
  return(pop(mystack));
}
