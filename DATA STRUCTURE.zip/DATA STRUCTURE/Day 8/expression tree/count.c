#include"exptree.h"
int nodecount(struct node *p)
{
  if(p==NULL)
  {
    return 0;
  }
  int lcount=nodecount(p->lchild);
  int rcount=nodecount(p->rchild);
  return(lcount+rcount+1);
}
