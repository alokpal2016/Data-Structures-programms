#include<stdio.h>
#include<stdlib.h>
#include<stdio_ext.h>
#define SIZE 100
struct node
{
  char data;
  struct node *lchild;
  struct node *rchild;
};
struct stack
{
  int top;
  struct node *sta[SIZE];
};
void preorder(struct node*);
void postorder(struct node*);
void inorder(struct node*);
struct node* expressiontree(char*,struct stack*);
void push(struct node*,struct stack*);
struct node*pop(struct stack*);
int treeheight(struct node*);
int nodecount(struct node*);
void mirrortree(struct node*);
void swap(struct node**,struct node**);
