#include"exptree.h"
void mirrortree(struct node *p)
{
  struct node *temp;
  if(p==NULL)
    return;
  mirrortree(p->lchild);
  mirrortree(p->rchild);
  temp=p->lchild;
  p->lchild=p->rchild;
  p->rchild=temp;

}
