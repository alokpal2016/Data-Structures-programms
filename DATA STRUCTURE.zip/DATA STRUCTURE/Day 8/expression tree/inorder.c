#include"exptree.h"
void inorder(struct node *p)
{
  if(p==NULL)
    return;
  inorder(p->lchild);
  printf("%c",p->data);
  inorder(p->rchild);
}
