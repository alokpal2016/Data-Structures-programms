#include<stdio.h>
int main()
{
  int a,b,c,max;
  printf("enter the velue to compare\n");
  scanf("%d%d%d",&a,&b,&c);
  printf("the no is:a=%d\nb=%d\nc=%d\n",a,b,c);
  if(a>b)
  {
    if(a>c)
    {
      printf("a is maximum=%d\n",a);
    }
    else
    {
      printf("c is max=%d\n",c);
    }
  }
  else if(b>c)
     {
        printf("b is maximum=%d\n",b);
     }
     else
     {
       printf("c is maximum=%d\n",c);
     }
}
