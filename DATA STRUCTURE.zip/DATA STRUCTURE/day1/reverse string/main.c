#include<stdio.h>
#include<string.h>
void revfunc( char[],int,char []);
void main()
{
	char str[]="abcde";
	char revstr[10];
	int i= strlen(str);
	revfunc(str,i-1,revstr);
	printf("%s",revstr);
	
	
}

void revfunc( char str[], int i, char revstr[])
{
	if(*str=='\0')
	return;
	revfunc(str+1,i-1,revstr);
	*(revstr+i)=*str;
}

