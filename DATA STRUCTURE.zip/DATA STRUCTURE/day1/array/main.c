#include<stdio.h>
#include<string.h>
#include<stdlib.h>
/*int reverse(int *str, int n)
{
  int temp;
  for(int i=0;i<n/2;i++)
  {
      temp=*(str+i);
      *(str+i)=*(str+n-i-1);
      *(str+n-i-1)=temp;
  }

}*/
int del(int *arr,int n)
{
  for(int i=0;i<=n;i++)
  {
    arr[i]='\0';
  }
}
int main()
{

  int *arr,n,i;
  printf("enter the no of element:");
  scanf("%d",&n);
  arr=(int*)malloc(n*sizeof(int));
  for(i=0;i<n;i++ )
  {
    scanf("%d",arr+i);
  }
  //reverse(arr,n);
  del(arr,n);
  for(i=0;i<n;i++ )
  {
    printf("%d",*(arr+i));
  }
 free(arr);
}
