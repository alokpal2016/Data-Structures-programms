float add(int ,int ,int ,int );
float mul(int ,int ,int ,int );
float div(int ,int ,int ,int );
