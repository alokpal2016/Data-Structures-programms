#include<stdio.h>
float add(int a,int b,int c,int d)
{
  int p,q;
  float sum;
  p=(a*d)+(b*c);
  q=(b*d);
  sum=(float)p/q;
  printf("sum is:%f\n",sum);
}
