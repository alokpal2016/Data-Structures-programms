#include<stdio.h>
float div(int a,int b,int c,int d)
{
  int p,q;
  float dive;
  p=a*d;
  q=b*c;
  dive=(float)p/q;
  printf("div is:%f\n",dive);
}
