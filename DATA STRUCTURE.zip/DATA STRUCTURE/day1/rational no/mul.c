#include<stdio.h>
float mul(int a,int b,int c,int d)
{
  int p,q;
  float mul;
  p=a*c;
  q=b*d;
  mul=(float)p/q;
  printf("mul is:%f\n",mul);
}
