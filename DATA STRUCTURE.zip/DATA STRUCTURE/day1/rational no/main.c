#include<stdio.h>
#include"rational.h"
int main()
{
  int p,q,r,s;
  printf("enter the velues\n");
  scanf("%d%d%d%d",&p,&q,&r,&s);
  if(q!=0 && s!=0)
  {
    printf("%d/%d and %d/%d is rational no.\n",p,q,r,s);
  }
  else
  {
    printf("number is not a rational no\n");
  }
  add(p,q,r,s);
  mul(p,q,r,s);
  div(p,q,r,s);
}
