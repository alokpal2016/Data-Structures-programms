#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
#include"postfix.h"
#define BLANK ' '
#define TAB '\t'
#define MAX 50
char infix[MAX],postfix[MAX];
int stack[MAX];
int top;
long int eval_postfix()
{
  long int a,b,temp,result;
  unsigned int i;
  for (i=0;i<strlen(postfix);i++)
  {
    if(postfix[i]<='9' && postfix[i]>='0')
          push(postfix[i]-'0');
    else
    {
      a=pop();
      b=pop();
      switch (postfix[i])
       {
        case '+':temp=a+b;
                 break;
        case '-':temp=b-a;
                 break;
        case '/':temp=b/a;
                 break;
        case '&':temp=b%a;
                 break;
        //case '^':temp=pow(b,a);
                // break;

      }
      push(temp);
    }
  }
  result=pop();
  return result;
}
