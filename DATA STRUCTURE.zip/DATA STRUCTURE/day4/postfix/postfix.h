void push(long int );
long int pop();
void infix_to_postfix();
long int eval_postfix(char* );
int priority(char );
int isempty();
int white_space(char);
