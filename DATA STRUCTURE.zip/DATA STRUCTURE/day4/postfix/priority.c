#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
#include"postfix.h"
#define BLANK ' '
#define TAB '\t'
#define MAX 50
char infix[MAX],postfix[MAX];
int stack[MAX];
int top;
int priority(char symbol)
{
  switch (symbol)
  {
    case '(':
            return 0;
    case '+':
    case '-':
            return 1;
    case '*':
    case '/':
    case '%':
            return 2;
    case '^':
            return 3;
    default:
            return 0;
  }
}
