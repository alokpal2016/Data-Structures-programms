#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
#include"postfix.h"
#define BLANK ' '
#define TAB '\t'
#define MAX 50
char infix[MAX],postfix[MAX];
int stack[MAX];
int top;
long int pop()
{
  if(isempty())
  {
    printf("stack is underflow\n");
    exit(1);
  }
  return (stack[top--]);
}
