#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
#include"postfix.h"
#define BLANK ' '
#define TAB '\t'
#define MAX 50
char infix[MAX],postfix[MAX];
int stack[MAX];
int top;
void infix_to_postfix()
{
  unsigned int i,p=0;
  char symbol,next;
  for(i=0;i<strlen(infix);i++)
  {
    symbol=infix[i];
    if(!white_space(symbol))
    {
    switch(symbol)
      {
        case '(': push(symbol);
                  break;
        case ')':while((next=pop())!='(')
                  postfix[p++]=next;
                  break;
        case '+':
        case '-':
        case '*':
        case '/':
        case '%':
        case '^':
           while(!isempty() && priority(stack[top])>=priority(symbol))
                   postfix[p++]=pop();
                push(symbol);
                break;
        default:
              postfix[p++]=symbol;

      }
    }
  }
   while(!isempty())
      postfix[p++]=pop();
  postfix[p]='\0';
}
