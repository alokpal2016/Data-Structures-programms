#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
#include"postfix.h"
#define BLANK ' '
#define TAB '\t'
#define MAX 50
char infix[MAX],postfix[MAX];
int stack[MAX];
int top;
long int main()
{
  long int velue;
  top=-1;
  printf("enter infix:\n" );
  gets(infix);
  infix_to_postfix();
  printf("postfix:%s\n",postfix);
  velue=eval_postfix(postfix);
  printf("velue of postfix expration is:%ld\n",velue);
}
