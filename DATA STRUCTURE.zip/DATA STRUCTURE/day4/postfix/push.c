#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
#include"postfix.h"
#define BLANK ' '
#define TAB '\t'
#define MAX 50
char infix[MAX],postfix[MAX];
int stack[MAX];
int top;
void push(long int symbol)
{
  if(top>MAX)
  {
    printf("stack is overflow\n");
    exit(1);
  }
  stack[++top]=symbol;
}
