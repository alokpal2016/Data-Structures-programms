#include<stdio.h>
#include<stdio_ext.h>
void main()
{
    int a[50],min,i,n,s,ans,h;
    char y;
    printf("Enter the no. of elements\n");
    scanf("%d",&n);
    for(i=0;i<n;i++)
      scanf("%d",&a[i]);
  while(1)
  {
    printf("Enter the search element\n");
    scanf("%d",&s);
      min=a[0]-s;
      if(min<0)
      min=-min;
      ans=a[0];
      for(i=0;i<n;i++)
      {
        h=a[i]-s;
        if(h<0)
        h=-h;
        if(h<min)
        {
          ans=a[i];
          min=h;
        }
      }
      printf("Closest element is %d\n",ans);
      printf("Y/N");
      __fpurge(stdin);
      scanf("%c",&y);
      if(y!='y')
      break;
  }

}
