#include<stdio.h>
#include<stdio_ext.h>
void bubblesort(int[],int);
void swap(int*,int*);
