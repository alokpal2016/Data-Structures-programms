#include<stdio.h>
#include<stdio_ext.h>
void heapsort(int [],int);
void maxheap(int [],int);
void swap(int*, int*);
