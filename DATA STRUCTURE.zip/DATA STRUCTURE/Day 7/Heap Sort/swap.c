void swap(int *c, int *b)
{
  int temp;
  temp=*c;
  *c=*b;
  *b=temp;
}
